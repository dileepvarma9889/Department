package com.Departementexample.Departement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartementApplication.class, args);
	}

}
