package com.Departementexample.Departement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartementApplicationTests {

	@Test
	void contextLoads() {
	}

}
